﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccessModifier.Inheritance
{
    class HdfcBank:Bank
    {
        static void Main(string[] args)
        {
            HdfcBank h = new HdfcBank();
            h.withdraw();
        }
    }
}
