﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccessModifier.Inheritance
{
    class Bank
    {
        int accno;
        string name;

        internal void withdraw()
        {
            Console.WriteLine("In withdraw");
        }

        internal void deposit()
        {
            Console.WriteLine("In deposit");
        }
    }
}
