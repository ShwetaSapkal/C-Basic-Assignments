﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P1
{
    class Program1
    {
       public void Display(int a)
        {
            Console.WriteLine("one argument");
        }

        public void Display(int a,int b)//method overloading
        {
            Console.WriteLine("Method with two parameters");
        }
    }
    class Program2:Program1
    {
        public void Display(int a)//overriding
        {
            Console.WriteLine(" ");
        }
    }
}