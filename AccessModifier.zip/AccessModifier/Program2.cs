﻿/*using System;
using System.Collections.Generic;
using System.Text;
using P1;

namespace P2
{
   internal class Program2
    {
        public void Add()
        {
            Console.WriteLine("In M1");
        }
        static void Main(string[] args)
        {
            
            Program3 pr3 = new Program3();
            pr3.M2();
        }
    }
}
*/