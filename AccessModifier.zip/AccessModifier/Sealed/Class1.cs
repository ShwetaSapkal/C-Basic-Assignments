﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccessModifier.Sealed
{
    class Class1
    {
        public virtual void Play()
        {
            Console.WriteLine("Play on ground");
        }

        internal virtual void Study()
        {
            Console.WriteLine("Study by reading books");
        }
    }

    class Class2 : Class1
    {
        public  override void Play()
        {
            
            Console.WriteLine("online video games");
        }
        internal sealed override  void Study()
        {
            Console.WriteLine("Online study");
        }

    }

    class Test
    {
        static void Main(string[] args)
        {
            Class1 c1 = new Class1();
            c1.Study();

            Class2 c2 = new Class2();

            c2.Study();
        }
      



    }

}
