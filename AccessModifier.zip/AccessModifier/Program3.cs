﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p1 //AccessModifier
{
    internal class Program3
    {
        public void M2()
        {
            Console.WriteLine("In M2");
        }
    }
}
